/**
*
* READ ME
* NhaTrangNet boombox child theme
* 
**/
_ Tạo 1 page tên category có shortcode [boombox-all-categories]


- Đăng ký user xong login lần đầu tiên sẽ vào trang chọn sở thích

- Chọn sở thích xong lưu lại sẽ vào trang world

- Bắt đầu từ lần login thứ 2 sẽ vào trang world luôn

* Mình đã cố gắng code gọn và dễ hiểu, có chú thích code

