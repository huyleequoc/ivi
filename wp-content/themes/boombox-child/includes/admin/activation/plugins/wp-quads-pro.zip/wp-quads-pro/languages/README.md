#  WP QUADS PRO I18n #

  To help translate, review, or improve a translation, write Rene Hermenau at support@wpquads.com


# Quick Start #

    In wp-quads-pro/languages/ you find a file named wp-quads-pro.po

    - Open it with the free editor: http://poedit.net/

    - Translate the strings and save it. Poedit automatically creates the file wp-quads-pro.mo

    - Rename this to your language specific translation. E.g. for italy the file is called wp-quads-pro-it_IT.mo and put it into the folder /wp-quads-pro/languages/

I really appreciate it if you like to send us the generated mo file. Every released trasnlation gets a one year license key for free

