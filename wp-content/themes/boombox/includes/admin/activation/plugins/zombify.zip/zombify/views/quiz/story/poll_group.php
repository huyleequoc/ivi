<div class="zf-type-wrapper"><i class="zf-icon zf-icon-type-poll"></i></div>

<div class="zf-item-wrapper">
	<?php echo $this->renderGroups(['story', 'poll', 'questions'], $group_name_prefix, $data, $action, ['story', 'poll'], 'questions', '', ''); ?>
</div>