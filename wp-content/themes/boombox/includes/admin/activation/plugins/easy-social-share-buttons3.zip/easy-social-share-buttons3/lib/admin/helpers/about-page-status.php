<div class="essb-control-content">
	<?php include_once(ESSB3_PLUGIN_ROOT.'lib/admin/helpers/about-page-header.php'); ?>
    <div class="panel panel-system-status active">
    
    <?php include_once(ESSB3_PLUGIN_ROOT.'lib/admin/helpers/system-status.php'); ?>
    
    </div>
</div>